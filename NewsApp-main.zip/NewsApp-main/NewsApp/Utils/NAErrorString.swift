//
//  NAErrorString.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

enum NAErrorString: String{
    
    case apiError = "Please check back later"
    case errorTitle = "Sorry!"

}
