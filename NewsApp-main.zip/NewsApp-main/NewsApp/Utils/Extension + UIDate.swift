//
//  UIDate+Extension.swift
//  Humm
//
//  Created by Hari Parasath on 17/02/23.
//

import UIKit



extension Date {
    
    func toString(_ format: String) -> String{
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        let strDate = dateFormatter.string(from: self)
        return strDate
        
    }
    
}
