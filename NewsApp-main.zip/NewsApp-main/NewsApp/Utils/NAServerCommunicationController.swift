//
//  NAServerCommunicationController.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

typealias NAAPICaller = NAServerCommunicationController

class NAServerCommunicationController{
    
    static var shared: NAServerCommunicationController! = NAServerCommunicationController()

    var baseURL: String{
        let info = Bundle.main.infoDictionary ?? [:]
        return info["BaseURL"] as! String
        
    }
    
    var queue: DispatchQueue! = DispatchQueue(label: Bundle.main.bundleIdentifier ?? "queue.app.humm.main", qos: .background, attributes: .concurrent, autoreleaseFrequency: .inherit, target: .global(qos: .userInitiated))

    public var operationQueue: OperationQueue! = {
        let operation = OperationQueue()
        operation.qualityOfService = .background
        operation.maxConcurrentOperationCount = 1
        operation.name = Bundle.main.bundleIdentifier
        return operation
    }()
    
    public var customSession: URLSession!
    
    func loadURLSession(){
        let configuration = URLSessionConfiguration.ephemeral
        // timeoutIntervalForRequest is 60 for reducing the request time out error while hitting the api.
        configuration.timeoutIntervalForRequest = 60
        customSession = URLSession(configuration: configuration, delegate: nil, delegateQueue: operationQueue)
    }
    
    func callAPI(_ urlString: String, method: NAAPIMethods = .GET, postData: Data? = nil, header: [String:String] = [:], params: [String:String] = [:], completionHandler:@escaping (Data?, Error?, Int) -> Void){
        
        guard let url = urlComponentsHandler(params: params, url: urlString)?.url else {
            return
        }
                
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringCacheData, timeoutInterval: 60)
        request.allHTTPHeaderFields = header
        request.httpBody = postData
        request.httpMethod = method.rawValue
   
        queue.async { [weak self] in
            self?.customSession.dataTask(with: request) { data, response, error in
                
                guard let urlResponse = response as? HTTPURLResponse else{
                    return
                }
                completionHandler(data, error, urlResponse.statusCode)
                
            }.resume()
        }
        
    }
    
    
    func urlComponentsHandler(params: [String: String]?, url: String) -> URLComponents? {
        
      var urlComponend = URLComponents(string: url)
      
      if let urlParams = params{
        var item = [URLQueryItem]()
        for (_, (key, value)) in urlParams.enumerated(){
          item.append(URLQueryItem(name: key, value: value))
        }
        urlComponend?.queryItems = item
      }
      return urlComponend
    }
    
}
