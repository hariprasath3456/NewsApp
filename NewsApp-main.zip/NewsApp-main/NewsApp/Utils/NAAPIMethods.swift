//
//  NAAPIMethods.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

enum NAAPIMethods: String{
    
    case GET
    case POST
    case PUT
    
}
