//
//  NAHomeTableViewCell.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import UIKit
import SDWebImage

class NAHomeTableViewCell: UITableViewCell {

    @IBOutlet weak var labelHeader: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var imageViewNews: UIImageView!

    var data: NAHealthChildData!{
        didSet{
            labelHeader.text = data.title
            labelDescription.text = data.selftext
            imageViewNews.sd_setImage(with: URL(string: data.thumbnail ?? ""))
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    
 }
