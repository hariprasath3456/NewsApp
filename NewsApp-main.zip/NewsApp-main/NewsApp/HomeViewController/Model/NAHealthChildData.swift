//
//  NAHealthChildData.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthChildData: Codable {
    let approvedAtUTC: String?
    let subreddit: String?
    let selftext, authorFullname: String?
    let saved: Bool?
    let modReasonTitle: String?
    let gilded: Int?
    let clicked: Bool?
    let title: String?
    let linkFlairRichtext: [NAHealthFlairRichtext]?
    let subredditNamePrefixed: String?
    let hidden: Bool?
    let pwls: Int?
    let linkFlairCSSClass: String?
    let downs: Int?
    let thumbnailHeight: Int?
    let topAwardedType: String?
    let hideScore: Bool?
    let name: String?
    let quarantine: Bool?
    let linkFlairTextColor: String?
    let upvoteRatio: Double?
    let authorFlairBackgroundColor: String?
    let subredditType: String?
    let ups, totalAwardsReceived: Int?
    let mediaEmbed: String?
    let thumbnailWidth: Int?
    let authorFlairTemplateID: String?
    let isOriginalContent: Bool?
    let userReports: [String]?
    let secureMedia: String?
    let isRedditMediaDomain, isMeta: Bool?
    let category: String?
    let secureMediaEmbed: String?
    let linkFlairText: String?
    let canModPost: Bool?
    let score: Int?
    let approvedBy: String?
    let isCreatedFromAdsUI, authorPremium: Bool?
    let thumbnail: String?
    let edited: Bool?
    let authorFlairCSSClass: String?
    let authorFlairRichtext: [NAHealthFlairRichtext]?
    let gildings: String?
    let postHint: String?
    let contentCategories: String?
    let isSelf: Bool?
    let modNote: String?
    let created: Date?
    let linkFlairType: String?
    let wls: Int?
    let removedByCategory, bannedBy: String?
    let authorFlairType: String?
    let domain: String?
    let allowLiveComments: Bool?
    let selftextHTML, likes, suggestedSort, bannedAtUTC: String?
    let urlOverriddenByDest: String?
    let viewCount: String?
    let archived, noFollow, isCrosspostable, pinned: Bool?
    let over18: Bool?
    let preview: NAHealthImagePreview?
    let allAwardings, awarders: [String]?
    let mediaOnly, canGild, spoiler, locked: Bool?
    let authorFlairText: String?
    let treatmentTags: [String]?
    let visited: Bool?
    let removedBy, numReports, distinguished: String?
    let subredditID: String?
    let authorIsBlocked: Bool?
    let modReasonBy, removalReason: String?
    let linkFlairBackgroundColor, id: String?
    let isRobotIndexable: Bool?
    let reportReasons: String?
    let author: String?
    let discussionType: String?
    let numComments: Int?
    let sendReplies: Bool?
    let whitelistStatus: String?
    let contestMode: Bool?
    let modReports: [String]?
    let authorPatreonFlair: Bool?
    let authorFlairTextColor: String?
    let permalink: String?
    let parentWhitelistStatus: String?
    let stickied: Bool?
    let url: String?
    let subredditSubscribers, createdUTC, numCrossposts: Int?
    let media: String?
    let isVideo: Bool?

    enum CodingKeys: String, CodingKey {
        case approvedAtUTC = "approved_at_utc"
        case subreddit, selftext
        case authorFullname = "author_fullname"
        case saved
        case modReasonTitle = "mod_reason_title"
        case gilded, clicked, title
        case linkFlairRichtext = "link_flair_richtext"
        case subredditNamePrefixed = "subreddit_name_prefixed"
        case hidden, pwls
        case linkFlairCSSClass = "link_flair_css_class"
        case downs
        case thumbnailHeight = "thumbnail_height"
        case topAwardedType = "top_awarded_type"
        case hideScore = "hide_score"
        case name, quarantine
        case linkFlairTextColor = "link_flair_text_color"
        case upvoteRatio = "upvote_ratio"
        case authorFlairBackgroundColor = "author_flair_background_color"
        case subredditType = "subreddit_type"
        case ups
        case totalAwardsReceived = "total_awards_received"
        case mediaEmbed = "media_embed"
        case thumbnailWidth = "thumbnail_width"
        case authorFlairTemplateID = "author_flair_template_id"
        case isOriginalContent = "is_original_content"
        case userReports = "user_reports"
        case secureMedia = "secure_media"
        case isRedditMediaDomain = "is_reddit_media_domain"
        case isMeta = "is_meta"
        case category
        case secureMediaEmbed = "secure_media_embed"
        case linkFlairText = "link_flair_text"
        case canModPost = "can_mod_post"
        case score
        case approvedBy = "approved_by"
        case isCreatedFromAdsUI = "is_created_from_ads_ui"
        case authorPremium = "author_premium"
        case thumbnail, edited
        case authorFlairCSSClass = "author_flair_css_class"
        case authorFlairRichtext = "author_flair_richtext"
        case gildings
        case postHint = "post_hint"
        case contentCategories = "content_categories"
        case isSelf = "is_self"
        case modNote = "mod_note"
        case created
        case linkFlairType = "link_flair_type"
        case wls
        case removedByCategory = "removed_by_category"
        case bannedBy = "banned_by"
        case authorFlairType = "author_flair_type"
        case domain
        case allowLiveComments = "allow_live_comments"
        case selftextHTML = "selftext_html"
        case likes
        case suggestedSort = "suggested_sort"
        case bannedAtUTC = "banned_at_utc"
        case urlOverriddenByDest = "url_overridden_by_dest"
        case viewCount = "view_count"
        case archived
        case noFollow = "no_follow"
        case isCrosspostable = "is_crosspostable"
        case pinned
        case over18 = "over_18"
        case preview
        case allAwardings = "all_awardings"
        case awarders
        case mediaOnly = "media_only"
        case canGild = "can_gild"
        case spoiler, locked
        case authorFlairText = "author_flair_text"
        case treatmentTags = "treatment_tags"
        case visited
        case removedBy = "removed_by"
        case numReports = "num_reports"
        case distinguished
        case subredditID = "subreddit_id"
        case authorIsBlocked = "author_is_blocked"
        case modReasonBy = "mod_reason_by"
        case removalReason = "removal_reason"
        case linkFlairBackgroundColor = "link_flair_background_color"
        case id
        case isRobotIndexable = "is_robot_indexable"
        case reportReasons = "report_reasons"
        case author
        case discussionType = "discussion_type"
        case numComments = "num_comments"
        case sendReplies = "send_replies"
        case whitelistStatus = "whitelist_status"
        case contestMode = "contest_mode"
        case modReports = "mod_reports"
        case authorPatreonFlair = "author_patreon_flair"
        case authorFlairTextColor = "author_flair_text_color"
        case permalink
        case parentWhitelistStatus = "parent_whitelist_status"
        case stickied, url
        case subredditSubscribers = "subreddit_subscribers"
        case createdUTC = "created_utc"
        case numCrossposts = "num_crossposts"
        case media
        case isVideo = "is_video"
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.approvedAtUTC = try? container?.decodeIfPresent(String.self, forKey: .approvedAtUTC)
        self.subreddit = try? container?.decodeIfPresent(String.self, forKey: .subreddit)
        self.selftext = try? container?.decodeIfPresent(String.self, forKey: .selftext)
        self.authorFullname = try? container?.decodeIfPresent(String.self, forKey: .authorFullname)
        self.saved = try? container?.decodeIfPresent(Bool.self, forKey: .saved)
        self.modReasonTitle = try? container?.decodeIfPresent(String.self, forKey: .modReasonTitle)
        self.gilded = try? container?.decodeIfPresent(Int.self, forKey: .gilded)
        self.clicked = try? container?.decodeIfPresent(Bool.self, forKey: .clicked)
        self.title = try? container?.decodeIfPresent(String.self, forKey: .title)
        self.linkFlairRichtext = try? container?.decodeIfPresent([NAHealthFlairRichtext].self, forKey: .linkFlairRichtext)
        self.subredditNamePrefixed = try? container?.decodeIfPresent(String.self, forKey: .subredditNamePrefixed)
        self.hidden = try? container?.decodeIfPresent(Bool.self, forKey: .hidden)
        self.pwls = try? container?.decodeIfPresent(Int.self, forKey: .pwls)
        self.linkFlairCSSClass = try? container?.decodeIfPresent(String.self, forKey: .linkFlairCSSClass)
        self.downs = try? container?.decodeIfPresent(Int.self, forKey: .downs)
        self.thumbnailHeight = try? container?.decodeIfPresent(Int.self, forKey: .thumbnailHeight)
        self.topAwardedType = try? container?.decodeIfPresent(String.self, forKey: .topAwardedType)
        self.hideScore = try? container?.decodeIfPresent(Bool.self, forKey: .hideScore)
        self.name = try? container?.decodeIfPresent(String.self, forKey: .name)
        self.quarantine = try? container?.decodeIfPresent(Bool.self, forKey: .quarantine)
        self.linkFlairTextColor = try? container?.decodeIfPresent(String.self, forKey: .linkFlairTextColor)
        self.upvoteRatio = try? container?.decodeIfPresent(Double.self, forKey: .upvoteRatio)
        self.authorFlairBackgroundColor = try? container?.decodeIfPresent(String.self, forKey: .authorFlairBackgroundColor)
        self.subredditType = try? container?.decodeIfPresent(String.self, forKey: .subredditType)
        self.ups = try? container?.decodeIfPresent(Int.self, forKey: .ups)
        self.totalAwardsReceived = try? container?.decodeIfPresent(Int.self, forKey: .totalAwardsReceived)
        self.mediaEmbed = try? container?.decodeIfPresent(String.self, forKey: .mediaEmbed)
        self.thumbnailWidth = try? container?.decodeIfPresent(Int.self, forKey: .thumbnailWidth)
        self.authorFlairTemplateID = try? container?.decodeIfPresent(String.self, forKey: .authorFlairTemplateID)
        self.isOriginalContent = try? container?.decodeIfPresent(Bool.self, forKey: .isOriginalContent)
        self.userReports = try? container?.decodeIfPresent([String].self, forKey: .userReports)
        self.secureMedia = try? container?.decodeIfPresent(String.self, forKey: .secureMedia)
        self.isRedditMediaDomain = try? container?.decodeIfPresent(Bool.self, forKey: .isRedditMediaDomain)
        self.isMeta = try? container?.decodeIfPresent(Bool.self, forKey: .isMeta)
        self.category = try? container?.decodeIfPresent(String.self, forKey: .category)
        self.secureMediaEmbed = try? container?.decodeIfPresent(String.self, forKey: .secureMediaEmbed)
        self.linkFlairText = try? container?.decodeIfPresent(String.self, forKey: .linkFlairText)
        self.canModPost = try? container?.decodeIfPresent(Bool.self, forKey: .canModPost)
        self.score = try? container?.decodeIfPresent(Int.self, forKey: .score)
        self.approvedBy = try? container?.decodeIfPresent(String.self, forKey: .approvedBy)
        self.isCreatedFromAdsUI = try? container?.decodeIfPresent(Bool.self, forKey: .isCreatedFromAdsUI)
        self.authorPremium = try? container?.decodeIfPresent(Bool.self, forKey: .authorPremium)
        self.thumbnail = try? container?.decodeIfPresent(String.self, forKey: .thumbnail)
        self.edited = try? container?.decodeIfPresent(Bool.self, forKey: .edited)
        self.authorFlairCSSClass = try? container?.decodeIfPresent(String.self, forKey: .authorFlairCSSClass)
        self.authorFlairRichtext = try? container?.decodeIfPresent([NAHealthFlairRichtext].self, forKey: .authorFlairRichtext)
        self.gildings = try? container?.decodeIfPresent(String.self, forKey: .gildings)
        self.postHint = try? container?.decodeIfPresent(String.self, forKey: .postHint)
        self.contentCategories = try? container?.decodeIfPresent(String.self, forKey: .contentCategories)
        self.isSelf = try? container?.decodeIfPresent(Bool.self, forKey: .isSelf)
        self.modNote = try? container?.decodeIfPresent(String.self, forKey: .modNote)
        self.created = try? container?.decodeIfPresent(Date.self, forKey: .created)
        self.linkFlairType = try? container?.decodeIfPresent(String.self, forKey: .linkFlairType)
        self.wls = try? container?.decodeIfPresent(Int.self, forKey: .wls)
        self.removedByCategory = try? container?.decodeIfPresent(String.self, forKey: .removedByCategory)
        self.bannedBy = try? container?.decodeIfPresent(String.self, forKey: .bannedBy)
        self.authorFlairType = try? container?.decodeIfPresent(String.self, forKey: .authorFlairType)
        self.domain = try? container?.decodeIfPresent(String.self, forKey: .domain)
        self.allowLiveComments = try? container?.decodeIfPresent(Bool.self, forKey: .allowLiveComments)
        self.selftextHTML = try? container?.decodeIfPresent(String.self, forKey: .selftextHTML)
        self.likes = try? container?.decodeIfPresent(String.self, forKey: .likes)
        self.suggestedSort = try? container?.decodeIfPresent(String.self, forKey: .suggestedSort)
        self.bannedAtUTC = try? container?.decodeIfPresent(String.self, forKey: .bannedAtUTC)
        self.urlOverriddenByDest = try? container?.decodeIfPresent(String.self, forKey: .urlOverriddenByDest)
        self.viewCount = try? container?.decodeIfPresent(String.self, forKey: .viewCount)
        self.archived = try? container?.decodeIfPresent(Bool.self, forKey: .archived)
        self.noFollow = try? container?.decodeIfPresent(Bool.self, forKey: .noFollow)
        self.isCrosspostable = try? container?.decodeIfPresent(Bool.self, forKey: .isCrosspostable)
        self.pinned = try? container?.decodeIfPresent(Bool.self, forKey: .pinned)
        self.over18 = try? container?.decodeIfPresent(Bool.self, forKey: .over18)
        self.preview = try? container?.decodeIfPresent(NAHealthImagePreview.self, forKey: .preview)
        self.allAwardings = try? container?.decodeIfPresent([String].self, forKey: .allAwardings)
        self.awarders = try? container?.decodeIfPresent([String].self, forKey: .awarders)
        self.mediaOnly = try? container?.decodeIfPresent(Bool.self, forKey: .mediaOnly)
        self.canGild = try? container?.decodeIfPresent(Bool.self, forKey: .canGild)
        self.spoiler = try? container?.decodeIfPresent(Bool.self, forKey: .spoiler)
        self.locked = try? container?.decodeIfPresent(Bool.self, forKey: .locked)
        self.authorFlairText = try? container?.decodeIfPresent(String.self, forKey: .authorFlairText)
        self.treatmentTags = try? container?.decodeIfPresent([String].self, forKey: .treatmentTags)
        self.visited = try? container?.decodeIfPresent(Bool.self, forKey: .visited)
        self.removedBy = try? container?.decodeIfPresent(String.self, forKey: .removedBy)
        self.numReports = try? container?.decodeIfPresent(String.self, forKey: .numReports)
        self.distinguished = try? container?.decodeIfPresent(String.self, forKey: .distinguished)
        self.subredditID = try? container?.decodeIfPresent(String.self, forKey: .subredditID)
        self.authorIsBlocked = try? container?.decodeIfPresent(Bool.self, forKey: .authorIsBlocked)
        self.modReasonBy = try? container?.decodeIfPresent(String.self, forKey: .modReasonBy)
        self.removalReason = try? container?.decodeIfPresent(String.self, forKey: .removalReason)
        self.linkFlairBackgroundColor = try? container?.decodeIfPresent(String.self, forKey: .linkFlairBackgroundColor)
        self.id = try? container?.decodeIfPresent(String.self, forKey: .id)
        self.isRobotIndexable = try? container?.decodeIfPresent(Bool.self, forKey: .isRobotIndexable)
        self.reportReasons = try? container?.decodeIfPresent(String.self, forKey: .reportReasons)
        self.author = try? container?.decodeIfPresent(String.self, forKey: .author)
        self.discussionType = try? container?.decodeIfPresent(String.self, forKey: .discussionType)
        self.numComments = try? container?.decodeIfPresent(Int.self, forKey: .numComments)
        self.sendReplies = try? container?.decodeIfPresent(Bool.self, forKey: .sendReplies)
        self.whitelistStatus = try? container?.decodeIfPresent(String.self, forKey: .whitelistStatus)
        self.contestMode = try? container?.decodeIfPresent(Bool.self, forKey: .contestMode)
        self.modReports = try? container?.decodeIfPresent([String].self, forKey: .modReports)
        self.authorPatreonFlair = try? container?.decodeIfPresent(Bool.self, forKey: .authorPatreonFlair)
        self.authorFlairTextColor = try? container?.decodeIfPresent(String.self, forKey: .authorFlairTextColor)
        self.permalink = try? container?.decodeIfPresent(String.self, forKey: .permalink)
        self.parentWhitelistStatus = try? container?.decodeIfPresent(String.self, forKey: .parentWhitelistStatus)
        self.stickied = try? container?.decodeIfPresent(Bool.self, forKey: .stickied)
        self.url = try? container?.decodeIfPresent(String.self, forKey: .url)
        self.subredditSubscribers = try? container?.decodeIfPresent(Int.self, forKey: .subredditSubscribers)
        self.createdUTC = try? container?.decodeIfPresent(Int.self, forKey: .createdUTC)
        self.numCrossposts = try? container?.decodeIfPresent(Int.self, forKey: .numCrossposts)
        self.media = try? container?.decodeIfPresent(String.self, forKey: .media)
        self.isVideo = try? container?.decodeIfPresent(Bool.self, forKey: .isVideo)
    }
    
}
