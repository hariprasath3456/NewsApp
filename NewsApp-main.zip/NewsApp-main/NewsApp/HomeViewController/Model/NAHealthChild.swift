//
//  NAHealthChild.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthChild: Codable {
    
    let kind: String?
    let data: NAHealthChildData?
    
    enum CodingKeys: CodingKey {
        case kind
        case data
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.kind = try? container?.decodeIfPresent(String.self, forKey: .kind)
        self.data = try? container?.decodeIfPresent(NAHealthChildData.self, forKey: .data)
    }
    
}
