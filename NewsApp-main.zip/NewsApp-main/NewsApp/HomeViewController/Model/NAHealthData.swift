//
//  NAHealthData.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthData: Codable {
    
    let after: String?
    let dist: Int?
    let modhash: String?
    let geoFilter: String?
    let children: [NAHealthChild]?
    let before: String?

    enum CodingKeys: String, CodingKey {
        case after
        case dist
        case modhash
        case geoFilter = "geo_filter"
        case children
        case before
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.after = try? container?.decodeIfPresent(String.self, forKey: .after)
        self.dist = try? container?.decodeIfPresent(Int.self, forKey: .dist)
        self.modhash = try? container?.decodeIfPresent(String.self, forKey: .modhash)
        self.geoFilter = try? container?.decodeIfPresent(String.self, forKey: .geoFilter)
        self.children = try? container?.decodeIfPresent([NAHealthChild].self, forKey: .children)
        self.before = try? container?.decodeIfPresent(String.self, forKey: .before)
    }
    
}
