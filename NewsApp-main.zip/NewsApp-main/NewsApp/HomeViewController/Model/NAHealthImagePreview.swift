//
//  NAHealthImagePreview.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthImagePreview: Codable {
    
    let images: [NAHealthImage]?
    let enabled: Bool?
    
    enum CodingKeys: CodingKey {
        case images
        case enabled
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.images = try? container?.decodeIfPresent([NAHealthImage].self, forKey: .images)
        self.enabled = try? container?.decodeIfPresent(Bool.self, forKey: .enabled)
    }
    
}

