//
//  NAHealthResponse.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthResponse: Codable {
    
    let kind: String?
    let data: NAHealthData?
    
    enum CodingKeys: CodingKey {
        case kind
        case data
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.kind = try? container?.decodeIfPresent(String.self, forKey: .kind)
        self.data = try? container?.decodeIfPresent(NAHealthData.self, forKey: .data)
    }
    
}




