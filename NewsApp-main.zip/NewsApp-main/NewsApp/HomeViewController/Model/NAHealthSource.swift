//
//  NAHealthSource.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthSource: Codable {
    
    let url: String?
    let width, height: Int?
    
    enum CodingKeys: CodingKey {
        case url
        case width
        case height
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.url = try? container?.decodeIfPresent(String.self, forKey: .url)
        self.width = try? container?.decodeIfPresent(Int.self, forKey: .width)
        self.height = try? container?.decodeIfPresent(Int.self, forKey: .height)
    }
    
}

