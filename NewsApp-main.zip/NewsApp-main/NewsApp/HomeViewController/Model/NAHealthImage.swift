//
//  NAHealthImage.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthImage: Codable {
    
    let source: NAHealthSource?
    let resolutions: [NAHealthSource]?
    let variants: String?
    let id: String?
    
    enum CodingKeys: CodingKey {
        case source
        case resolutions
        case variants
        case id
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.source = try? container?.decodeIfPresent(NAHealthSource.self, forKey: .source)
        self.resolutions = try? container?.decodeIfPresent([NAHealthSource].self, forKey: .resolutions)
        self.variants = try? container?.decodeIfPresent(String.self, forKey: .variants)
        self.id = try? container?.decodeIfPresent(String.self, forKey: .id)
    }
    
}

