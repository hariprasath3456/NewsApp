//
//  NAHealthFlairRichtext.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import Foundation

struct NAHealthFlairRichtext: Codable {
    
    let a: String?
    let e: String?
    let u: String?
    let t: String?
    
    enum CodingKeys: CodingKey {
        case a
        case e
        case u
        case t
    }
    
    init(from decoder: Decoder) throws {
        let container = try? decoder.container(keyedBy: CodingKeys.self)
        self.a = try? container?.decodeIfPresent(String.self, forKey: .a)
        self.e = try? container?.decodeIfPresent(String.self, forKey: .e)
        self.u = try? container?.decodeIfPresent(String.self, forKey: .u)
        self.t = try? container?.decodeIfPresent(String.self, forKey: .t)
    }
    
}
