//
//  NAHomeViewController.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import UIKit

class NAHomeViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var loaderIndicatorView: UIActivityIndicatorView!

    var controller: NAHomeController! = NAHomeController()
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        if #available(iOS 13, *) {
            return .darkContent
        } else {
            return .default
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        controller.delegate = self
        controller.callAPI()
        
    }


}

//MARK: Data Pass
extension NAHomeViewController{

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let cell = sender as? NAHomeTableViewCell, let controller = segue.destination as? NADetailViewController{
            controller.data = cell.data
        }
    }
    
}

extension NAHomeViewController: NAHomeViewDelegate{

    func startLoading() {
        self.view.isUserInteractionEnabled = false
        self.loaderIndicatorView.isHidden = false
        self.loaderIndicatorView.startAnimating()
    }
    
    func endLoading() {
        self.view.isUserInteractionEnabled = true
        self.loaderIndicatorView.stopAnimating()
    }
    
    func reloadData() {
        self.tableView.reloadData()
    }
    
}

//MARK: UITableView DataSource

extension NAHomeViewController: UITableViewDataSource{
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return controller.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: NAHomeTableViewCell.self), for: indexPath) as! NAHomeTableViewCell
        cell.data = controller.data[indexPath.row].data
        return cell
        
    }
    
}

//#MARK: UITableView Datasource

extension NAHomeViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.controller.loadMoreData(indexPath)
    }

}
