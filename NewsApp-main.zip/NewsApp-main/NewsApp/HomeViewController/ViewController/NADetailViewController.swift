//
//  NADetailViewController.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import UIKit

class NADetailViewController: UIViewController {

    @IBOutlet weak var labelHeader: UILabel!
    @IBOutlet weak var labelDescription: UILabel!
    @IBOutlet weak var imageViewNews: UIImageView!
    @IBOutlet weak var labelCount: UILabel!
    @IBOutlet weak var textView: UITextView!

    var data: NAHealthChildData!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        if #available(iOS 13, *) {
            return .lightContent
        } else {
            return .default
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
  
        labelHeader.text = data.title
        labelCount.text = String(data.ups ?? 0)
        labelDescription.text = (data.selftext ?? "") + "\n\n" + (data.created?.toString("MMM dd, YYYY HH:mm:ss") ?? "")
        imageViewNews.sd_setImage(with: URL(string: data.thumbnail ?? ""))
        setAttributedPrivicyLink()
        
    }
    
    //
    @IBAction func backAction(){
        navigationController?.popViewController(animated: true)
    }
    
}


extension NADetailViewController{
    func setAttributedPrivicyLink() {
        
        let attributedString = NSMutableAttributedString(string: "Read more @\(data.subreddit ?? "")",attributes: [.font : UIFont.boldSystemFont(ofSize: 17), .foregroundColor: UIColor.white])
        let foundRange = attributedString.mutableString.range(of: "Read more")
        attributedString.addAttributes([.link: ""], range: foundRange)
        textView.attributedText = attributedString
        textView.textAlignment = .left
        textView.linkTextAttributes = [.underlineStyle: NSUnderlineStyle.single.rawValue,
                                       .font : UIFont.boldSystemFont(ofSize: 17),
                                       .foregroundColor: UIColor.white]
    }


}
