//
//  NAHomeController.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import UIKit

class NAHomeController: NSObject  {

    lazy var workItem: DispatchWorkItem? = nil

    weak var delegate: NAHomeViewDelegate?
    var data: [NAHealthChild]! = []
    var allData: NAHealthResponse!

    func callAPI(_ pageID: String? = nil){
        
        delegate?.startLoading()
        let url = NAAPICaller.shared.baseURL
        NAAPICaller.shared.callAPI(url, params: ["limit": "10", "after" : pageID ?? ""]) { [weak self] (data, error, statusCode)  in
            DispatchQueue.main.async { [weak self] in
                self?.delegate?.endLoading()
                if statusCode == 200{
                    guard let data = data, let value = try? JSONDecoder().decode(NAHealthResponse.self, from: data) else {
                        self?.delegate?.showAlert(message: NAErrorString.errorTitle.rawValue, title: NAErrorString.apiError.rawValue)
                        return
                    }
                    
                    self?.allData = value
                    self?.data.append(contentsOf: value.data?.children ?? [])
                    self?.delegate?.reloadData()
                    
                }else{
                    self?.delegate?.showAlert(message: NAErrorString.errorTitle.rawValue, title: NAErrorString.apiError.rawValue)
                }
            }
        }
    }
    
}

extension NAHomeController{
    
    func loadMoreData(_ indexPath: IndexPath){
        
        guard let count = self.data?.count, indexPath.row >= (count - 1) else {
            return
        }
        
        guard let page = self.allData.data?.after else {
            return
        }
        self.setAPICallWorkItem(page)

    }
    
    func setAPICallWorkItem(_ page: String){
        
        self.workItem?.cancel()
        self.workItem = nil
        self.workItem = DispatchWorkItem(block: { [weak self] in
            self?.callAPI(page)
        })
        DispatchQueue.main.asyncAfter(deadline: .now() + .microseconds(999), execute: self.workItem!)
        
    }
    
}
