//
//  NAHomeViewDelegate.swift
//  NewsApp
//
//  Created by Hari Parasath on 17/02/23.
//

import UIKit

protocol NAHomeViewDelegate: AnyObject {
    
    func showAlert(message: String, title: String)
    func reloadData()
    func startLoading()
    func endLoading()

}

extension NAHomeViewDelegate where Self: UIViewController{
    
    func showAlert(message: String, title: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
}
